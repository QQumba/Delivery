create view warehouse_product(warehouse_id, id, name, price, description, quantity) as
SELECT w.id AS warehouse_id,
       p.id,
       p.name,
       p.price,
       p.description,
       pi.quantity
FROM warehouse w
         JOIN product_instance pi ON w.id = pi.warehouse_id
         JOIN product p ON pi.product_id = p.id
ORDER BY w.id;

alter table warehouse_product
    owner to postgres;

