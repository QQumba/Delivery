create procedure add_date_info(wh_id integer)
    language sql
as
$$
UPDATE warehouse
    SET info = to_char(current_date,'YYYY-MM-DD')
    WHERE id = wh_id;
$$;

alter procedure add_date_info(integer) owner to postgres;

