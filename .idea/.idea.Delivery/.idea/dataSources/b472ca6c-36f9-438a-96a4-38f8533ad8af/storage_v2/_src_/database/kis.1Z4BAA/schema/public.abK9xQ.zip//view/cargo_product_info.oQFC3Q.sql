create view cargo_product_info (id, name, price, quantity, warehouse_id, destination_warehouse_id, delivery_date) as
SELECT p.id,
       p.name,
       p.price,
       pi.quantity,
       pi.warehouse_id,
       c.destination_warehouse_id,
       c.delivery_date
FROM product p
         JOIN product_instance pi ON p.id = pi.product_id
         JOIN cargo c ON pi.id = c.product_instance_id;

alter table cargo_product_info
    owner to postgres;

