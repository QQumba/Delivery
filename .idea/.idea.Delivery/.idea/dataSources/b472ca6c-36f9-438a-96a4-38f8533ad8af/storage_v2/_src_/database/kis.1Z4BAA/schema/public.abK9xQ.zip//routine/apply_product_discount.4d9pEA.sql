create procedure apply_product_discount(processed_warehouse_id integer, discount integer)
    language sql
as
$$
UPDATE product
SET price = price - price * discount / 100
WHERE id IN
      (
          SELECT p.id
          FROM product p
                   INNER JOIN product_instance pi on p.id = pi.product_id
                   INNER JOIN warehouse w on pi.warehouse_id = w.id
          WHERE w.id = processed_warehouse_id
      )
$$;

alter procedure apply_product_discount(integer, integer) owner to postgres;

