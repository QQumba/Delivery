create procedure add_product_description(min_quantity integer, max_quantity integer)
    language sql
as
$$
UPDATE product p
    SET description = 'Abundance'
    WHERE p.id IN (
        SELECT t.id
        FROM total_product_quantity t
        WHERE t.quantity > max_quantity);

    UPDATE product p
    SET description = 'Lack'
    WHERE p.id IN (
        SELECT t.id
        FROM total_product_quantity t
        WHERE t.quantity < min_quantity);
$$;

alter procedure add_product_description(integer, integer) owner to postgres;

