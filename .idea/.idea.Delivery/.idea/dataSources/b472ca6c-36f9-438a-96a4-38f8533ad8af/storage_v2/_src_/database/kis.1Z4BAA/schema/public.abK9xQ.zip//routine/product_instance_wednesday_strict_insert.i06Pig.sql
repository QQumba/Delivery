create function product_instance_wednesday_strict_insert() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (select extract(dow from now()) = 3) THEN
        raise exception 'Сьогодні середа';
    END IF;
END;
$$;

alter function product_instance_wednesday_strict_insert() owner to postgres;

