create procedure add_expensive_product_info(processed_warehouse_id integer)
    language sql
as
$$
UPDATE warehouse
SET info = 'The most expensive product is: ' || p.name
FROM (
         SELECT p.name
         FROM product p
                  INNER JOIN product_instance pi on p.id = pi.product_id
                  INNER JOIN warehouse w on w.id = pi.warehouse_id
         WHERE w.id = processed_warehouse_id
         ORDER BY p.price DESC
             FETCH NEXT 1 ROW ONLY) p
WHERE id = processed_warehouse_id;
$$;

alter procedure add_expensive_product_info(integer) owner to postgres;

