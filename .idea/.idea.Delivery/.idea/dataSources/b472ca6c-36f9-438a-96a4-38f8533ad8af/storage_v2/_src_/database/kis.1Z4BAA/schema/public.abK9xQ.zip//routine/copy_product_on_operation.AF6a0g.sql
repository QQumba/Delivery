create function copy_product_on_operation() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (TG_OP = 'UPDATE') THEN
        raise debug 'update';
        IF (mod(nextval('product_update_count'), 3) = 0) THEN
            INSERT INTO product_copy
            SELECT nextval('product_copy_id'), new.id, new.name, new.price, new.description, 'UPDATE';
        END IF;
    END IF;
    IF (TG_OP = 'DELETE') THEN
        IF (mod(nextval('product_delete_count'), 2) = 0) THEN
            INSERT INTO product_copy
            SELECT nextval('product_copy_id'), old.id, old.name, old.price, old.description, 'DELETE';
        END IF;
    END IF;
    RETURN NULL;
END;
$$;

alter function copy_product_on_operation() owner to postgres;

