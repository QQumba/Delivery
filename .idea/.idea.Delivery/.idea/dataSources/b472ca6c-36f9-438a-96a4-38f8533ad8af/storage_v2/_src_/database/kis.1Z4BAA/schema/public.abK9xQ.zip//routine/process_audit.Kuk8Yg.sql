create function process_audit() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (TG_OP = 'INSERT') THEN
        INSERT INTO audit_pi SELECT nextval('audit_pi_id'), 'product', now(), 'INSERT';
    ELSIF (TG_OP = 'UPDATE') THEN
        INSERT INTO audit_pi SELECT nextval('audit_pi_id'), 'product', now(), 'UPDATE';
    ELSIF (TG_OP = 'DELETE') THEN
        INSERT INTO audit_pi SELECT nextval('audit_pi_id'), 'product', now(), 'DELETE';
    END IF;
    RETURN NULL;
END;
$$;

alter function process_audit() owner to postgres;

