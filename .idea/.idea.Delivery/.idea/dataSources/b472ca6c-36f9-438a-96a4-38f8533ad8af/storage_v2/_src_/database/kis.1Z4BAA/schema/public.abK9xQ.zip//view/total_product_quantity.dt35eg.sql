create view total_product_quantity(id, quantity) as
SELECT p.id,
       sum(pi.quantity) AS quantity
FROM product_instance pi
         JOIN product p ON p.id = pi.product_id
GROUP BY p.id;

alter table total_product_quantity
    owner to postgres;

