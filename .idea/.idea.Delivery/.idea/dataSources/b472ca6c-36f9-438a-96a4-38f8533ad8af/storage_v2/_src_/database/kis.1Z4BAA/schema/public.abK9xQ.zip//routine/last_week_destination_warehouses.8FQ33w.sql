create function last_week_destination_warehouses(product_quantity_threshold integer) returns text
    language plpgsql
as
$$
declare
    names text;
begin
    select string_agg(w.name, ', ')
    into names
    from (
             select w.name
             from warehouse w
                      join cargo c on w.id = c.destination_warehouse_id
                      join product_instance pi on c.product_instance_id = pi.id
             where c.delivery_date < current_date
               and c.delivery_date > cast(current_date - interval '7' day as date)
             group by w.id
             having sum(pi.quantity) < product_quantity_threshold
         ) w;

    return names;
end;
$$;

alter function last_week_destination_warehouses(integer) owner to postgres;

