create function registration_audit_records_for_update() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (old.name != new.name) THEN
        INSERT INTO audit_update_pi SELECT nextval('audit_update_pi_id'), (SELECT max(command_id) FROM audit_pi),
                                           'name', old.name, new.name;
        RETURN NEW;
    ELSIF (old.price != new.price) THEN
        INSERT INTO audit_update_pi SELECT nextval('audit_update_pi_id'), (SELECT max(command_id) FROM audit_pi),
                                           'price', old.price, new.price;
        RETURN NEW;
    ELSIF (old.description != new.description) THEN
        INSERT INTO audit_update_pi SELECT nextval('audit_update_pi_id'), (SELECT max(command_id) FROM audit_pi),
                                           'description', old.description, new.description;
        RETURN NEW;
    END IF;
    RETURN NULL;
END;
$$;

alter function registration_audit_records_for_update() owner to postgres;

