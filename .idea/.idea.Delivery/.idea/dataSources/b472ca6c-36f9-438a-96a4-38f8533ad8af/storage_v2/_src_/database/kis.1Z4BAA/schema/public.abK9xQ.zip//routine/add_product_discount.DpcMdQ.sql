create procedure add_product_discount(product_id integer, discount integer)
    language sql
as
$$
UPDATE product p
SET description = 'Discount ' || discount || ' %'
WHERE p.id = product_id
$$;

alter procedure add_product_discount(integer, integer) owner to postgres;

